import React,{useEffect,useRef,useState} from 'react';

const DEFAULTS=
{
  work:25,
  shortBreak:5,
  longBreak:15,
  cyclesBeforeLong:4,
  autoStart:false,
};

function formatTime(totalSeconds)
{
  const m=Math.floor(totalSeconds/60).toString().padStart(2,'0');
  const s=(totalSeconds%60).toString().padStart(2,'0');
  return `${m}:${s}`;
}

export default function PomodoroTimer()
{
  const [settings,setSettings]=useState(()=>
    {
    try
    {
      const saved=localStorage.getItem('pomo.settings');
      return saved?JSON.parse(saved) : DEFAULTS;
    } catch
    {
      return DEFAULTS;
    }
  });

  const[mode,setMode]=useState('work');
  const[isRunning,setIsRunning]=useState(false);
  const[secondsLeft,setSecondsLeft]=useState(settings.work*60);
  const[cycleCount,setCycleCount]=useState(0);
  const[history,setHistory]=useState(()=>
    {
    try
    {
      const saved=localStorage.getItem('pomo.history');
      return saved?JSON.parse(saved):[];
    } catch
    {
      return [];
    }
  });

  const intervalRef=useRef(null);
  const audioRef=useRef(null);
  
  useEffect(()=>
    {
    try
    {
      localStorage.setItem('pomo.settings',JSON.stringify(settings));
    }catch{}
    if(mode==='work')
      setSecondsLeft(settings.work*60);
    if(mode==='short')
      setSecondsLeft(settings.shortBreak*60);
    if(mode==='long')
      setSecondsLeft(settings.longBreak*60);
  },[settings,mode]);
  
  useEffect(()=>
    {
    if(!isRunning) return;
    intervalRef.current=setInterval(()=>
      {
      setSecondsLeft(prev=>prev-1);
    },1000);
    return()=>clearInterval(intervalRef.current);
  }, [isRunning]);
  
  useEffect(()=>
    {
    if(secondsLeft>0)
      return;
    if(audioRef.current)
      audioRef.current.play().catch(()=>{});
    if(typeof Notification!=='undefined' && Notification.permission==='granted')
      {
      new Notification('Pomodoro',{body:`${mode==='work'?'Work session finished':'Break finished'}`});
      }
    
    const entry={mode,endedAt:new Date().toISOString()};
    setHistory(h=>{const next=[entry,...h].slice(0,50);
      try
      {
        localStorage.setItem('pomo.history',JSON.stringify(next));}catch{}
        return next;
      });
    
    setIsRunning(false);
    if(mode==='work')
      {
      const nextCycle=cycleCount+1;
      setCycleCount(nextCycle);
      const shouldLong=nextCycle%settings.cyclesBeforeLong===0;
      setMode(shouldLong?'long':'short');
    } else
      {
      setMode('work');
      }
    
    if(settings.autoStart)
      setTimeout(()=>setIsRunning(true),500);
  },[secondsLeft]);

  function startPause()
  {
    setIsRunning(r=>!r);
  }

  function reset()
  {
    setIsRunning(false);
    setCycleCount(0);
    setMode('work');
    setSecondsLeft(settings.work*60);
  }

  function changeSetting(key,value)
  {
    setSettings(s=>({...s,[key]:value}));
  }

  function requestNotificationPermission()
  {
    if(typeof Notification==='undefined')
      return alert('Notification API not supported in this browser');
    Notification.requestPermission().then(p=>{if(p==='granted')
      alert('Notifications allowed.');
      else alert('Notifications denied or dismissed.');
    });
  }
  
  const totalSeconds=mode==='work'?settings.work*60:mode==='short'?settings.shortBreak*60:settings.longBreak*60;
  const progress=1-(secondsLeft/totalSeconds || 0);

  return(
    <div className="max-w-lg mx-auto p-6 bg-white/80 backdrop-blur rounded-2xl shadow-lg">
      <audio ref={audioRef} src="https://actions.google.com/sounds/v1/alarms/alarm_clock.ogg" preload="auto" />
      <h2 className="text-2xl font-semibold mb-4">Pomodoro Timer</h2>
      <div className="flex items-center gap-4">
        <div className="flex-1">
          <div className="text-sm text-gray-500">Mode</div>
          <div className="mt-1 flex gap-2">
            <button onClick={()=>setMode('work')}className={`px-3 py-1 rounded-full${mode==='work'?'bg-indigo-600 text-white':'bg-gray-100'}`}>Work</button>
            <button onClick={()=>setMode('short')}className={`px-3 py-1 rounded-full${mode==='short'?'bg-indigo-600 text-white':'bg-gray-100'}`}>Short Break</button>
            <button onClick={()=>setMode('long')}className={`px-3 py-1 rounded-full${mode==='long'?'bg-indigo-600 text-white':'bg-gray-100'}`}>Long Break</button>
          </div>
          <div className="mt-4 text-center">
            <div className="text-6xl font-mono">{formatTime(Math.max(0,secondsLeft))}</div>
            <div className="mt-2 text-sm text-gray-500">Cycle:{cycleCount}</div>
            <div className="mt-4 flex gap-2 justify-center">
              <button onClick={startPause}className="px-4 py-2 rounded-lg bg-green-500 text-white">{isRunning?'Pause':'Start'}</button>
              <button onClick={reset}className="px-4 py-2 rounded-lg bg-red-500 text-white">Reset</button>
            </div>
            <div className="h-2 bg-gray-200 rounded-full mt-4 overflow-hidden">
              <div style={{ width:`${Math.min(100,Math.max(0,progress*100))}%`}}className="h-full bg-indigo-500"></div>
            </div>
          </div>
        </div>
        <div className="w-48">
          <div className="text-sm text-gray-500">Settings</div>
          <div className="mt-2 space-y-2">
            <label className="block">
              <div className="text-xs text-gray-600">Work(minutes)</div>
              <input type="number"min={1}value={settings.work}onChange={e=>changeSetting('work',Math.max(1,Number(e.target.value) || 1))} className="w-full mt-1 p-2 rounded-lg border" />
            </label>
            <label className="block">
              <div className="text-xs text-gray-600">Short Break(minutes)</div>
              <input type="number" min={1}value={settings.shortBreak}onChange={e=>changeSetting('shortBreak',Math.max(1,Number(e.target.value) || 1))} className="w-full mt-1 p-2 rounded-lg border" />
            </label>
            <label className="block">
              <div className="text-xs text-gray-600">Long Break(minutes)</div>
              <input type="number" min={1}value={settings.longBreak}onChange={e=>changeSetting('longBreak',Math.max(1,Number(e.target.value) || 1))} className="w-full mt-1 p-2 rounded-lg border" />
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" checked={settings.autoStart}onChange={e=>changeSetting('autoStart',e.target.checked)} />
              <span className="text-sm">Auto-start next session</span>
            </label>
            <label className="block">
              <div className="text-xs text-gray-600">Cycles before long break</div>
              <input type="number" min={1}value={settings.cyclesBeforeLong}onChange={e=>changeSetting('cyclesBeforeLong',Math.max(1,Number(e.target.value) || 1))} className="w-full mt-1 p-2 rounded-lg border" />
            </label>

            <button onClick={requestNotificationPermission}className="w-full mt-2 p-2 rounded-lg border">Enable notifications</button>
          </div>
        </div>
      </div>
      <div className="mt-6">
        <h3 className="font-medium">History</h3>
        <div className="mt-2 max-h-40 overflow-auto text-sm text-gray-600">
          {history.length===0?<div className="text-xs text-gray-400">No history yet!!</div>:
          (
            <ul className="space-y-1">
              {history.map((h,i)=>
              (
                <li key={i}className="flex justify-between">
                  <span>{h.mode}</span>
                  <span className="text-xs text-gray-500">{new Date(h.endedAt).toLocaleString()}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}